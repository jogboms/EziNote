import {enableProdMode} from 'angular2/core';
import {bootstrap} from 'angular2/platform/browser';
import {RouteParams, ROUTER_PROVIDERS} from 'angular2/router';
import {App} from './components/app';

import {LocationStrategy, HashLocationStrategy} from 'angular2/platform/common';

import {TimeService, NotesService, SlideService, SettingsService} from "js/services/index";
import {Store, provideStore} from "js/library/store/index";
import reducers from "js/reducers/index";

const SERVICES = [
  TimeService,
  NotesService,
  SlideService,
  SettingsService
];

// enableProdMode();

bootstrap(App, [
  provideStore(reducers),
  ...SERVICES
  ]);
