import {Injectable, provide, OpaqueToken} from "angular2/core";
import {Observable} from "rxjs/Observable";
import {Subject} from "rxjs/Subject";
import {BehaviorSubject} from "rxjs/BehaviorSubject";
import "rxjs/Rx";

export interface Reducer extends Function {}

export interface Action {
  type: string;
  payload?: any;
}

const __createStore = (reducers: {[key: string] : Reducer}, initialStates: any = {}): Store => (new Store()).create(reducers, initialStates);

export const INIT_DISPATCH = 'INITIAL_STORE';


export const provideStore = (reducers: {[key: string] : Reducer}, initialStates: any = {}) => {
  return [
    provide('INITIAL_STATES', {useValue: initialStates}),
    provide('Reducers', {useValue: reducers}),
    provide(Store, {useFactory: __createStore, deps: ['Reducers', 'INITIAL_STATES']}),
    // {provide: Store, useFactory: __createStore, deps: [Reducers]},
    // {provide: Reducers, useValue: reducers}
  ]
};

class Redux extends BehaviorSubject<T> {
  constructor(state: any = null) {
    super(state)
  }
}

export class Store extends Subject<T> {
  reducers: {[name: string]: Redux} = {};

  constructor(state: any = null) {
    super(state)
  }

  select(name): Observable<any, Action>{
    return this.reducers[name].distinctUntilChanged();
  }

  create (reducers: {[key: string]: Reducer}, initialStates: any = {}): Store {
    if(reducers){
      this.reducers = Object.keys(reducers).reduce((a, n) => {
        if(typeof reducers[n] === 'function'){
          let initialState = initialStates.hasOwnProperty(n) ? initialStates[n]: undefined;
          let redux$ = new Redux(reducers[n](initialState, {type: INIT_DISPATCH, payload: {}}));
          a[n] = redux$.scan(reducers[n]);
        }
        return a;
      }, {});
    }
    return this;
  }

  dispatch(action: Action): void{
    Object.keys(this.reducers).forEach(n => this.reducers[n].next(action));
  }
}
