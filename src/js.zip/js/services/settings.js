import {Injectable} from "angular2/core";
import {Observable} from "rxjs/Observable";
import {Subject} from "rxjs/Subject";
import {BehaviorSubject} from "rxjs/BehaviorSubject";
import "rxjs/Rx";

import {Store, Action} from "js/library/store/index";

@Injectable()
export class SettingsService {
  constructor(store: Store){
    this.store = store;
  }

  select(){
    return this.store.select('settings');
  }

  dispatch(action: Action){
    this.store.dispatch(action);
  }
}
