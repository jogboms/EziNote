import {Injectable} from "angular2/core";
import {Observable} from "rxjs/Observable";
import {Subject} from "rxjs/Subject";
import {BehaviorSubject} from "rxjs/BehaviorSubject";
import "rxjs/Rx";

class Store extends Subject {
  constructor(args) {
    super(args);
    this.R = args;
    Object.keys(r).forEach(x => this.R[x] = new BehaviorSubject(r[x]));
  }

  select(name){
    return this.R[name].distinctUntilChanged()
  }

  dispatch(y) {
    Object.keys(this.R).forEach(x => this.R[x].next(y));
  }
}

let S = new Store({});
let r = {a: 1, b: 2, c: 3};

S.select('a').subscribe((x) => console.log('Calling from A: '+ x));
S.select('b').subscribe((x) => console.log('Calling from B: '+ x));
S.select('c').subscribe((x) => console.log('Calling from C: '+ x));

setInterval(() => S.dispatch(Math.floor(Math.random()*5)), 1500);



import DB from "../storage/ezinote";
import {NoteModel} from "../models/note";

const NOTES_DB = DB.collection("notes", {primaryKey: "id"});

@Injectable()
export class NotesService {
  notes: NoteModel[] = [];
  DATA: BehaviorSubject<any> = new BehaviorSubject([]);

  constructor(){
    this.DATA.take(1).subscribe(x => console.log('Initialized DB...'));

    NOTES_DB.load((x) => this.DATA.next(NOTES_DB.data().map(this.__fix)))


  }

  create(insert: Object): NoteModel{
    let p = NOTES_DB.insert(Object.assign({}, insert, {
      created: new Date,
      updated: new Date
    }));
    this.notes.unshift(p.inserted[0]);
    NOTES_DB.save()
    return p.inserted[0]
  }

  edit(note: NoteModel, update: NoteModel): NoteModel{
    let p = NOTES_DB.update({id: note.id}, {
      title:update.title,
      content:update.content,
      updated: new Date
    });
    this.notes.splice(this.notes.indexOf(p[0]), 1);
    this.notes.unshift(p[0]);
    NOTES_DB.save()
    return p[0];
  }

  fetch(): Observable<NoteModel[]>{
    return Observable.from(this.DATA.filter(x => x.length))
      .map(x => this.notes = x.sort(this.__sort))
  }

  search(query: string): Observable<NoteModel[]>{
    return Observable.of(NOTES_DB.find({title: new RegExp(query, 'i')}))
      .map(x => x.sort(this.__sort))
      .do(x => this.notes = x)
  }

  sort(state: boolean): Observable<NoteModel[]>{
    return Observable.of(this.notes)
      .map(x => x.sort(state == true ? this.__sort_alt_desc : this.__sort_alt_asc))
      .do(x => this.notes = x)
  }

  __fix(note: NoteModel): NoteModel{
    return new NoteModel(Object.assign({}, note, {
      date: new Date(note.date.toString()),
      created: new Date(note.created.toString()),
      updated: new Date(note.updated ? note.updated.toString() : note.created.toString())
    }));
  }

  __sort(a:NoteModel, b:NoteModel): number{
    if(a.updated.getTime() > b.updated.getTime())
      return -1;
    else if(a.updated.getTime() < b.updated.getTime())
      return 1;
  }

  __sort_alt_desc(a:NoteModel, b:NoteModel): number{
    if(a.created.getTime() > b.created.getTime())
      return -1;
    else if(a.created.getTime() < b.created.getTime())
      return 1;
  }

  __sort_alt_asc(a:NoteModel, b:NoteModel): number{
    if(a.created.getTime() > b.created.getTime())
      return 1;
    else if(a.created.getTime() < b.created.getTime())
      return -1;
  }
}
