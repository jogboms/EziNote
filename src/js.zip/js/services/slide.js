import {Injectable} from "angular2/core";
import {Observable} from "rxjs/Observable";
import {BehaviorSubject} from "rxjs/BehaviorSubject";
import "rxjs/Rx";

@Injectable()
export class SlideService {
  slider: BehaviorSubject = new BehaviorSubject(['main', {}]);

  constructor(){}

  slide(page: string, params: object = {}): Observable {
    if(page){
     this.slider.next([page, params]);
    }
    return this.slider;
  }
}
