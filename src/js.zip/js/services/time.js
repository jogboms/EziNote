import {Injectable} from "angular2/core";
import {Observable} from "rxjs/Observable";
import "rxjs/Rx";

@Injectable()
export class TimeService {
  constructor(){}

  init(){
    return Observable.interval(1000).map((i) => new Date);
  }
}
