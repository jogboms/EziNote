import settings from './settings';

export default {
  settings: settings
}
