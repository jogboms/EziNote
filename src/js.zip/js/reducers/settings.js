import {Reducer} from "js/library/store/index";

const store = () => localStorage.hasOwnProperty('name') && localStorage.name ? JSON.parse(localStorage.name) : {
      user: '',
      isList: false,
    };

export default <Reducer> (state = {}, {type, payload}: Action) => {
  // console.log('Type '+ type);
  // console.log('State ', state);
  // console.log('Payload ', payload);
  switch(type){
    case 'GET':
      return store();
    case 'UPDATE':
      let _state = Object.assign({}, state, payload);
      localStorage.name = JSON.stringify(_state);
      return _state;
    default:
      return store();
  }
};
