interface Note {
  title: string;
  content: string;
  created: Date;
  updated: Date;
  date: Date;
  editing: boolean;
  viewing: boolean;
  state: boolean;
  greeting_code: string;
  greeting: string;
  time: string;
}

export class NoteModel implements Note {
  constructor(args) {
    Object.assign(this, args)
    // console.log(this);
  }
}
