let DB = (new ForerunnerDB()).db("ezinote")

window['DB'] = DB;

export default DB;
