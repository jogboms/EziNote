import {Component, EventEmitter, Input, ViewChild} from 'angular2/core';
import {ROUTER_DIRECTIVES, Router, Location} from "angular2/router";

import {SlideService, SettingsService} from 'js/services/index';

@Component({
  moduleId: module.id,
  selector: 'menu-bar',
  templateUrl: 'menubar.html',
  styleUrls: ['./menubar.css'],
  directives: [ROUTER_DIRECTIVES],
})
export class Menubar {
  @Input() user;
  @ViewChild('input') input;
  show_modal = [];
  _slider: SlideService;

  constructor(S: SlideService, s: SettingsService){
    this._slider = S;
    this._settings = s;
    this.error = false;
    this.date = new Date();
  }

  ngOnInit(){
    this.show_modal['user'] = this.user ? !this.user.length : true;
  }

  onSwitch(e, page){
    this._slider.slide(page);
    e.preventDefault();
  }

  onModalShow(e, name){
    this.show_modal[name] = true;
    e.preventDefault();
  }

  onModalHide(name){
    this.show_modal[name] = false;
  }

  onModalSave(e){
    var name = this.input.nativeElement.value.trim()

    if(name.length > 3){
      this.error = false;
      this.onModalHide('user');
      this._settings.dispatch({type: 'UPDATE', payload: {user: name}});
    }
    else {
      this.error = true;
    }

    e.preventDefault()
  }
}
