import {Component, Input} from "angular2/core";

import {SlideService} from 'js/services/slide';

@Component({
  moduleId: module.id,
  selector: 'card-item',
  templateUrl: './card.html',
  styleUrls: ['./card.css'],
})
export class CardItem {
  _slider: SlideService;

  @Input() note;
  @Input() state = true;

  constructor(S: SlideService){
    this._slider = S;
  }

  ngOnInit(){}

  onPreview(e){
    this._slider.slide('preview', this.note);
    e.preventDefault();
  }
}


@Component({
  selector: 'card',
  template: `
    <card-item [note]="note" [state]="state" class="item {{ !state ? 'col-md-6' : 'col-md-3 col-xs-6' }}"></card-item>
  `,
  styles: [`
    .item {
      display: block;
      transition: all .5s ease-in-out;
    }
  `],
  directives: [CardItem]
})
export class Card {
  @Input() note;
  @Input() state = true;
}
