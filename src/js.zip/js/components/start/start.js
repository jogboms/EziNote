import {Component, EventEmitter, ViewChild, Input, Output} from "angular2/core";
import { Observable } from 'rxjs/Observable';
import 'rxjs/Rx';
// import 'rxjs/add/observable/fromEvent';
// import 'rxjs/add/operator/map';
// import 'rxjs/add/operator/filter';

@Component({
  moduleId: module.id,
  selector: 'start',
  templateUrl: './start.html',
  styleUrls: ['./start.css'],
})
export class Start {
  @Input() note;
  @Input() user;
  @Output() onChangeEvent: EventEmitter = new EventEmitter;
  @Output() onSaveEvent: EventEmitter = new EventEmitter;
  @ViewChild('input') inputElement;
  limit: number = 3;

  ngOnAfterView(){
    this.inputElement.nativeElement.focus();
  }

  onKeyUp(e){
    this.note.content = this.inputElement.nativeElement.value.trim();

    if(e.keyCode == 13 && this.note.content.length > this.limit){
      this.onChangeEvent.emit([this.note.title, this.note.content])
    }
  }
}
