import {Window} from '../nw/main';
import {Component} from "angular2/core";

import {Menubar} from './menubar/menubar';
import {Book} from './book/book';
import {Note} from './note/note';
import {Preview} from './preview/preview';
import {Start} from './start/start';

import {TimeService, NotesService, SlideService, SettingsService} from 'js/services/index';
import {NoteModel} from 'js/models/index';

@Component({
  moduleId: module.id,
  selector: 'main',
  templateUrl: './app.html',
  styleUrls: ['./app.css'],
  directives: [Menubar, Book, Note, Start, Preview],
})
export class App {
  _time: TimeService = null;
  _notes: NotesService = null;
  _slider: SlideService = null;
  _settings: SettingsService = null;
  time = 'hh:ss';
  notes: Array<NoteModel> = [];
  notes_memoize: Array<NoteModel> = [];
  notes_search: boolean = false;
  switch = 'main';

  constructor(T: TimeService, N: NotesService, S: SlideService, s: SettingsService){
    this._time = T;
    this._notes = N;
    this._slider = S;
    this._settings = s;
    this.note = {}
    this.preview = {}

    this.note.time = this.time;
    this.note.title = '';
    this.note.content = '';
    this.note.success = false;
    this.bookopen = false;

    // this._settings.select();
    this._settings.select().subscribe(s => {
      // console.log('Settings State: ', s);
      this.settings = s;
      // this.user = s.user ? s.user : '';
      // this.isList = s.isList ? s.isList : false;
    })
      // this.user = 'weee';

    this.loading = true;

    this.Window = Window;
    this.title = this.Window.App.name
  }

  ngOnInit(){
    this._notes.fetch().subscribe((notes) => this.notes = notes);

    this._slider.slide().subscribe((page) => {
      this.onSwitch(page[0]);
      if(page[0] == 'preview'){
        this.onPreview(page[1]);
      }
    });

    this._time.init().subscribe((date) => {
      this.note.date = date;
      this.note.state = 'am';
      var hours = date.getHours()
      var mins = date.getMinutes()
      this.note.greeting = 'Morning';
      this.note.greeting_code = 0;
      if(hours >= 12){
        if(hours > 12) hours -= 12;

        this.note.state = 'pm';
        this.note.greeting = 'Afternoon';
        this.note.greeting_code = 1;

        if(hours >= 5){
          this.note.greeting = 'Evening';
          this.note.greeting_code = 2;
        }
      }

      if(hours <= 9) hours = '0'+hours;

      if(mins <= 9) mins = '0'+mins;

      this.note.time = hours+':'+mins;
      // this.loading = false;

      // console.log(date)
    })
  }

  onChangeEvent(note){
    [this.note.title, this.note.content] = note;
  }

  onSaveEvent(note){
    this._notes.create(note)
  }

  onSearch(query){
    if(query.length > 1){
      this.notes_search = true;
      this.notes_memoize = Object.assign({}, this.notes);
      this._notes.search(query).subscribe((notes) => this.notes = notes);
    }
  }

  onCancel(){
    /* @todo Fix visiting the database again */
    this._notes.fetch().subscribe((notes) => this.notes = notes);
    // if(this.notes_search){
    //   console.log('use to');
    //   this.notes = this.notes_memoize;
    //   this.notes_search = false;
    // }
  }

  onSort(state: boolean){
    this._notes.sort(state).subscribe((notes) => this.notes = notes);
  }

  onSwitch(page){
    this.switch = page;
  }

  onPreview(note){
    this.preview = Object.assign({editing: false, viewing: true}, note);
  }
}
