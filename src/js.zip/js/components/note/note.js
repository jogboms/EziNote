import {Component, EventEmitter, Input, Output} from "angular2/core";
import {Card} from "../card/card";

@Component({
  moduleId: module.id,
  selector: 'note',
  templateUrl: './note.html',
  styleUrls: ['./note.css'],
  directives: [Card],
})
export class Note {
  @Input() user;
  @Input() note;
  @Output() onChangeEvent: EventEmitter = new EventEmitter;
  @Output() onSaveEvent: EventEmitter = new EventEmitter;

  onKeyUp(t, c){
    this.note.title = t.value.trim();
    // this.note.content = c.value.trim();

    this.onChangeEvent.emit([this.note.title, this.note.content])
  }

  onSave(){
    this.onSaveEvent.emit({
      title: this.note.title,
      date: this.note.date,
      time: this.note.time,
      state: this.note.state,
      content: this.note.content
    })

    this.success = true;

    setTimeout(() => this.success = false, 5000)
  }

  onViewNote(e){
    this.note.viewing = !(this.note.editing = false);

    e.preventDefault()
  }

  onEditNote(e){
    this.note.viewing = !(this.note.editing = true);

    e.preventDefault()
  }

  ngOnInit(){
    this.note = Object.assign({editing: true, viewing: false}, this.note);
  }

  ngAfterViewInit(){
    this.summernote = $("#summernote");

    this.summernote.summernote({focus: true});

    this.summernote.on('summernote.change', (x, content) => {
      this.note.content = content;
    });
  }
}
