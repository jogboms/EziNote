import {Component, EventEmitter, Input} from "angular2/core";
import {Card} from "../card/card";
import {Note} from "../note/note";

import {NotesService} from "services/notes";

@Component({
  moduleId: module.id,
  selector: 'preview',
  template: '<note (onSaveEvent)="onSaveEvent($event)" [user]="user" [note]="note"></note>',
  directives: [Card, Note],
})
export class Preview {
  _notes: NotesService;
  @Input() user;
  @Input() note;

  constructor(n: NotesService){
    this._notes = n;
  }

  ngOnInit(){}

  onSaveEvent(note){
    this._notes.edit(this.note, note)
  }
}
