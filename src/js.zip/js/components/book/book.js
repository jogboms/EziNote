import {Component, EventEmitter, Input, Output} from "angular2/core";
import {Card} from "../card/card";

import {SettingsService} from 'js/services/settings';

@Component({
  moduleId: module.id,
  selector: 'book',
  templateUrl: './book.html',
  styleUrls: ['./book.css'],
  directives: [Card],
})
export class Book {
  isSort = false;
  isList = true;

  @Input() notes;
  @Input() isList;
  @Output() onSortEvent: EVentEmitter = new EventEmitter;
  @Output() onSearchEvent: EVentEmitter = new EventEmitter;
  @Output() onCancelEvent: EVentEmitter = new EventEmitter;

  constructor(s: SettingsService){
    this._settings = s;
  }

  onSearch(e){
    this.isSearch = true;
    this.onSearchEvent.emit(e.value.trim());
  }

  onSwitch(state){
    this.isList = state;

    this._settings.dispatch({type: 'UPDATE', payload: {isList: this.isList}});
  }

  onCancel(e){
    this.isSearch = false;
    this.isSort = false;
    e.value = '';
    this.onCancelEvent.emit();
  }

  onSort(){
    this.isSort = !this.isSort;
    this.onSortEvent.emit(this.isSort);
  }
}
